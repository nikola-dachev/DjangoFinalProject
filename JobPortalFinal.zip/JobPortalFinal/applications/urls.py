from django.urls import path
from JobPortalFinal.applications import views


urlpatterns = [
    # Private pages (for Job Seekers)
    path('my-applications/', views.JobSeekerApplicationListView.as_view(), name='jobseeker applications'),

    # Private pages (for Employers)
    path('for-job/<int:job_id>/', views.EmployerApplicationListView.as_view(), name='employer applications'),
    path('<int:pk>/detail/', views.ApplicationDetailView.as_view(), name='application_detail'),

    # Employers managing applications
    path('<int:pk>/accept/', views.accept_application, name='accept application'),
    path('<int:pk>/reject/', views.reject_application, name='reject application'),
]
