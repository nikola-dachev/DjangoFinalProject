from django.shortcuts import render, get_object_or_404, redirect
from django.views.generic import ListView, DetailView
from .models import Application
from django.contrib.auth.decorators import login_required

from django.contrib.auth.mixins import LoginRequiredMixin


# Job Seeker's application list view (Private)
class JobSeekerApplicationListView(LoginRequiredMixin, ListView):
    model = Application
    template_name = 'applications/jobseeker_applications.html'

    def get_queryset(self):
        # Show only the applications for the current authenticated job seeker
        return Application.objects.filter(applicant=self.request.user)


# Employer's view of applications for a specific job (Private)
class EmployerApplicationListView(LoginRequiredMixin, ListView):
    model = Application
    template_name = 'applications/employer_applications.html'


    def get_queryset(self):
        # Show applications for a specific job posted by the current employer
        return Application.objects.filter(job_id=self.kwargs['job_id'], job__posted_by=self.request.user)


# Detailed view of a single application (Private)
class ApplicationDetailView(LoginRequiredMixin, DetailView):
    model = Application
    template_name = 'applications/application_detail.html'



# Function-based views for accepting or rejecting an application (Private for Employers)
@login_required
def accept_application(request, pk):
    application = get_object_or_404(Application, pk=pk)

    # Ensure the current user is the owner of the job posting
    if application.job.posted_by != request.user:
        return redirect('employer_applications', job_id=application.job.id)

    # Update the status of the application
    application.status = 'Accepted'
    application.save()

    return redirect('employer_applications', job_id=application.job.id)


@login_required
def reject_application(request, pk):
    application = get_object_or_404(Application, pk=pk)

    # Ensure the current user is the owner of the job posting
    if application.job.posted_by != request.user:
        return redirect('employer_applications', job_id=application.job.id)

    # Update the status of the application
    application.status = 'Rejected'
    application.save()

    return redirect('employer_applications', job_id=application.job.id)
